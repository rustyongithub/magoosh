#! /bin/bash
java -jar MagooshVocabulary.jar