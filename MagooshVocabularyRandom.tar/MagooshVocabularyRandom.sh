#! /bin/bash
java -jar MagooshVocabularyRandom.jar